$(document).ready(function(){
  $('.button-collapse').sideNav();
});